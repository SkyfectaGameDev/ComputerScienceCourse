let firstName = "Alisha";
console.log(firstName);

let age = 21;
console.log(age);

let alishaAge = true;
console.log(alishaAge);

let fruit = ["apple", "orange", "melon"];
console.log(fruit[0]);

let myArray = [
    ["Latte", 1],
    ["Cappuciono", 2]
];
console.log(myArray[0][1]);

if (firstName === "Alisha")
{
    
}