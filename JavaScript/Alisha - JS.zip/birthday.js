// ----- Birthday Activity -----
const date = new Date("2023-01-24");
const birthday = new Date("2001-08-30");
const nextBirthday = new Date("2023-08-30");

console.log(birthday.getDate() - date.getDate());