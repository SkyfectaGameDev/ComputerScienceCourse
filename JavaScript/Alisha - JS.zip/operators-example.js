let a = 5;
let b = 50;
let c;

// ----- Addition -----
a = a + 5;
console.log(a);

// ----- Subtraction -----
a = a - 2;
console.log(a);

// ----- Addition (Shortened) -----
b += 5;
console.log(b);

// ----- Subtracting One Variable From Another -----
c = b - a;
console.log(c);

// ----- Multiplication -----
a *= 8;
console.log(a);

// ----- Division -----
a /= 4;
console.log(a);

// ----- Addition Without Changing The Variable -----
console.log(a * 12);